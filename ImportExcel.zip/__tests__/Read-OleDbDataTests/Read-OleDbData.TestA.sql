select
    ROUND(F1) as [A1]
from
    [sheet3$A1:A1]